"""Forked by ai_translate plugin: lxml replaced with stdlib
xml.etree.ElementTree so the package has no third-party dependency.

Behavior mirrors the original wzyddg parser:
  1. try a normal parse (ElementTree honors the XML encoding declaration);
  2. on failure, decode manually with candidate encodings, normalize and parse.
"""

from typing import Any, Dict, List, Tuple
import xml.etree.ElementTree as etree
import os
import re
from .xRayTextAnalyzer import *
from .entityDefinition import *

# I will separate those included xml as standalone xml with full structure


def extract_entity_from_root(root) -> List[TextEntity]:
    if root is None:
        return []
    children = [root] if root.tag == 'string' else list(root)

    res = []
    for ent in children:
        entChildren = list(ent)
        langDict = dict()
        for lang in entChildren:
            if lang.text is not None and len(lang.text) > 0:
                curText = re.sub(r'[\n]', '', lang.text)
                langDict[lang.tag] = curText
        if ent.attrib.get("id") is not None:
            res.append(TextEntity(ent.attrib.get("id"), langDict))

    return res


def parse_xray_text_xml(filePath: str, candidateEncodings: List[str] = ["cp1251"]) -> List[TextEntity]:
    root = None

    try:
        tree = etree.parse(filePath)
        return extract_entity_from_root(tree.getroot())

    except Exception:
        wholeText = None
        f = None
        for encoding in candidateEncodings:
            try:
                f = open(filePath, "r", encoding=encoding)
                wholeText = f.read()
            except UnicodeDecodeError:
                if f is not None:
                    f.close()
                    f = None
                print(" ├──" + filePath + " is not encoded with " + encoding)
                continue
            else:
                f.close()
                print(" ├──" + filePath + " successfully decoded with " + encoding)
                break

        if wholeText is None:
            return []

        try:
            wholeText = normalize_xml_string(wholeText)
            root = etree.fromstring(wholeText)
        except (etree.ParseError, ValueError) as err:
            print(filePath + " is not a parsable xml")
            print(err)

    return extract_entity_from_root(root)


def parse_xray_cfgxml_xml(filePath: str, candidateEncodings: List[str] = ["cp1251"]) -> Tuple[str, set, str]:
    successEncoding = ""
    wholeText = None
    f = None
    for encodingIndex in range(len(candidateEncodings)):
        encoding = candidateEncodings[encodingIndex]
        try:
            # if last candidate, read any way
            if encodingIndex == len(candidateEncodings) - 1:
                f = open(filePath, "r", encoding=encoding, errors="ignore")
                print(" ├──" + filePath + " is forced decoded with " + encoding)
            else:
                f = open(filePath, "r", encoding=encoding)
            wholeText = f.read()
            successEncoding = encoding
        except UnicodeDecodeError:
            f.close()
            f = None
            print(" ├──" + filePath + " is not encoded with " + encoding)
            continue
        else:
            f.close()
            break

    wholeText = normalize_xml_string(
        wholeText, needFixST=False, deleteHeader=False)

    guys = getConfigXmlPotentialTexts(wholeText)

    return (wholeText, guys, successEncoding)


def parse_xray_script_file(filePath: str, candidateEncodings: List[str] = ["cp1251"]) -> Tuple[str, set]:
    wholeText = None
    f = None
    for encoding in candidateEncodings:
        try:
            f = open(filePath, "r", encoding=encoding)
            wholeText = f.read()
        except UnicodeDecodeError:
            f.close()
            f = None
            print(" ├──" + filePath + " is not encoded with " + encoding)
            continue
        else:
            f.close()
            print(" ├──" + filePath + " is successfully decoded with " + encoding)
            break

    guys = getScriptPotentialTexts(wholeText)

    return (wholeText, guys)


def parse_xray_ltx_file(filePath: str, candidateEncodings: List[str] = ["cp1251"]) -> Tuple[str, set, str]:
    successEncoding = ""
    wholeText = None
    f = None
    for encodingIndex in range(len(candidateEncodings)):
        encoding = candidateEncodings[encodingIndex]
        try:
            # if last candidate, read any way
            if encodingIndex == len(candidateEncodings) - 1:
                f = open(filePath, "r", encoding=encoding, errors="ignore")
                print(" ├──" + filePath + " is forced decoded with " + encoding)
            else:
                f = open(filePath, "r", encoding=encoding)
            wholeText = f.read()
            successEncoding = encoding
        except UnicodeDecodeError:
            f.close()
            f = None
            print(" ├──" + filePath + " is not encoded with " + encoding)
            continue
        else:
            f.close()
            break

    guys = getLtxPotentialTexts(wholeText)

    return (wholeText, guys, successEncoding)


def read_plain_text(filePath: str, candidateEncodings: List[str] = ["cp1251", 'cp1252', 'utf-8']):
    wholeText = None
    f = None
    for encoding in candidateEncodings:
        try:
            f = open(filePath, "r", encoding=encoding)
            wholeText = f.read()
        except UnicodeDecodeError:
            f.close()
            f = None
            print(" ├──" + filePath + " is not encoded with " + encoding)
            continue
        else:
            f.close()
            print(" ├──" + filePath + " successfully decoded with " + encoding)
            break

    return wholeText
